***************************************************
PLACE YOUR OWN GAMES/ROMS .nes IN THIS FOLDER /NES

***************************************************
------------------------------------------------------
-                                                    -
- Ported to ZX Spectrum Next by Victor Trucco - 2020 -
-                                                    -
------------------------------------------------------
from fpganes port for ZXUNO 2016 DistWave


ATARI & SEGA GENESIS/MEGADRIVE JOYSTICKS, VGA VIDEO


- From multcart menu, use joystick to navigate to the folder /NES and use FIRE to load the selected ROM.

- Support from menu for selecting 3 / 6 button joysticks

- RESET (green) button to reset the game

- DRIVE (yellow) button for menu


PS/2 KEYBOARD KEYS

- Arrow keys to navigate menu / Enter to select

- Holding ESC, returns the multcart menu.

- Keys 1 / 2 as START and FIRE 2


ALL CREDITS TO ORIGINAL AUTHORS 
