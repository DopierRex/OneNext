Written by em00k
NextSID engine by KevB

When loaded click load pt3, point to the PT3 folder and load
a tune of your choice. 

Twiddle with the settings until you get a sound you like. 

"save nt3" will save the current settigns for the that pt3 with
the extension nt3, this will auto load when you next load the associated
pt3 file.

If you mess the settings up too much, click "reset" and this will
pop back the default settings. Most of the songs have presets already
defined.

Enjoy
