******************************************************

PLACE YOUR OWN GAMES/ROMS .dsk IN THIS FOLDER /CPC6128

******************************************************

PS/2 KEYBOARD, ATARI STANDARD JOYSTICK, VGA/RGB VIDEO

Keys
----
- F12 - disk menu
- Ctrl-Alt-Delete - reset machine
- Ctrl-Alt-Backspace - reset to BIOS
- END - greenscreen mono mode.
- Scroll Lock - toggle scan doubler on/off

Attention!
 
- If your monitor does not give a signal, press the Scroll - Lock key, this key switches between 15 and 31khz.
- Hitting reset randomly moves the screen horizontally sometimes causing the scan lines
  to swap 123456->214365. Keep pressing reset fixes this. 

Disk image support
------------------
This supports:
- RAW format, 40 track, 9 sector, 512 byte sectors, and will assume a sequential sector numbering,
  starting from 0xc1.
- CPC Emu extended format, and standard CPC Emu format, limited to 512 byte sector block and no 
  copy protected images at present. Maximum 80 tracks 10 sectors and up to 839.5k image size.
- Two disk drives.


AmstradCPC6128 core
===================
Port to ZX Spectrum Next / N-GO by ManuFerHi.
Original AmstradCPC464 core, written by Miguel Angel Rodriguez Jodar
enhanced by Microjack with 128kb update, and disk emulation reading / writing from SDcard.

ALL CREDITS ATTRIBUTED TO ORIGINAL AUTHORS 
