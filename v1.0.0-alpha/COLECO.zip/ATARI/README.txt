**********************************************************************
PLACE GAMES/ROMS .a26 IN THIS FOLDER /ATARI
**********************************************************************

WORKS WITH PS/2 KEYBOARD, ATARI STANDARD JOYSTICK, VGA VIDEO

- Needs a PS/2 keyboard to access the menu (Esc key) and load roms

------------------------------------------------------
-                                                    -
- Ported to ZX Spectrum Next by Victor Trucco - 2018 -
-                                                    -
------------------------------------------------------

Port of the A2601 FPGA implementation for the ZXUNO
---------------------------------------------------------------------------------

ALL CREDITS TO THE AUTHORS

